/* This file was automatically generated.  Do not edit! */
void gsum_vec_int(int *c,int *r,int n);
int gmin_int(int c);
int gmax_int(int c);
int gsum_int(int c);
double gmin_double(double c);
double gmax_double(double c);
double gsum_double(double c);
extern MPI_Comm Comm;
