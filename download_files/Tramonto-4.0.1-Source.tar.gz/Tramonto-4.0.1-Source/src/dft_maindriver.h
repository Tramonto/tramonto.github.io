/* This file was automatically generated.  Do not edit! */
void dftmain(double *engptr);
int main(int argc,char *argv[]);
