/* This file was automatically generated.  Do not edit! */
void print_cont_variable_user_plugin(int cont_type,FILE *fp,int Loca_contID);
void print_cont_type_user_plugin(int cont_type,FILE *fp,int Loca_contID);
void assign_param_user_plugin(int cont_type,int Loca_contID,double param);
double get_init_param_user_plugin(int cont_type,int Loca_contID);
